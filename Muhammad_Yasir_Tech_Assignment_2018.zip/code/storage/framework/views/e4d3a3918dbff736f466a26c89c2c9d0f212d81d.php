<?php if(isset($view)): ?>
    <p class="text-info">
        <?php if(isset($answers[$question->id])): ?>
            <?php
                $id = $answers[$question->id]->answer;
                $ids = json_decode($id);
                $options = json_decode($data->options);
                $options = collect($options->values);
                $options = $options->keyBy('id');
                $values = [];
                foreach ($ids as $id){
                  $values[] = $options[$id]->value;
                }
            ?>
            <?php echo e(implode(', ',$values)); ?>

        <?php else: ?>
            N/A
        <?php endif; ?>
    </p>
<?php else: ?>
    <?php
        $options = json_decode($data->options);
        $id=[];
        if(isset($answers[$question->id])){
           $id = json_decode($answers[$question->id]->answer);
        }
    ?>
    <?php $__empty_1 = true; $__currentLoopData = $options->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <div class="form-check">
            <input class="form-check-input" type="checkbox"  name="question_id[<?php echo e($data->id); ?>][]"
                   id="option-<?php echo e($option->id); ?>"
                   value="<?php echo e($option->id); ?>" <?php echo e(in_array($option->id,$id)?'checked':''); ?>>
            <label class="form-check-label" for="option-<?php echo e($option->id); ?>"><?php echo e($option->value); ?></label>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /var/www/test-projects/survey/resources/views/surveys/fields/checkbox.blade.php ENDPATH**/ ?>