<?php if(isset($view)): ?>
    <p class="text-info">
        <?php echo e(isset($answers[$question->id])?$answers[$question->id]->answer:'N/A'); ?>

    </p>
<?php else: ?>
    <input class="form-control" type="text" name="question_id[<?php echo e($data->id); ?>]" value="<?php echo e(isset($answers[$question->id])?$answers[$question->id]->answer:''); ?>">
<?php endif; ?><?php /**PATH /var/www/test-projects/survey/resources/views/surveys/fields/input.blade.php ENDPATH**/ ?>