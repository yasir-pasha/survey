<?php $__env->startSection('content'); ?>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h4 class="float-left"><?php echo e($survey->name); ?></h4>
                <div class="float-right"><b>Completed Date:</b> <?php echo e(\Carbon\Carbon::parse($survey_interest->updated_at)->format('d-m-Y h:i A')); ?></div>
            </div>


            <div class="card-body">
                <div>
                    <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="form-group">
                            <label class="question_text" data-question_id="<?php echo e($question->id); ?>"
                                   data-question_type="<?php echo e($question->field_type); ?>"
                                   data-is_required="0"><?php echo e($question->question); ?>:</label>

                            <?php echo $__env->make('surveys.fields.'.$question->field_type,['data'=>$question,'answers'=>$answers,'view'=>true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-md-12">
                            <p>No Question found!</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/test-projects/survey/resources/views/surveys/view.blade.php ENDPATH**/ ?>