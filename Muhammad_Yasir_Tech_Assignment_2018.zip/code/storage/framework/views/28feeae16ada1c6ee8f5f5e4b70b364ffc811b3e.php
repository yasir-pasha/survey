<?php if(isset($view)): ?>
    <p class="text-info">
        <?php if(isset($answers[$question->id])): ?>
            <?php
                $id = $answers[$question->id]->answer;
                $options = json_decode($data->options);
$options = collect($options->values);
$options = $options->keyBy('id');

            ?>
            <?php echo e($options[$id]->value); ?>

        <?php else: ?>
            N/A
        <?php endif; ?>
    </p>
<?php else: ?>
    <?php
        $options = json_decode($data->options);
        $id='N/A-';
        if(isset($answers[$question->id])){
           $id = $answers[$question->id]->answer;
        }
    ?>
    <select id="inputState" class="form-control" name="question_id[<?php echo e($data->id); ?>]">
        <option value="">Choose <?php echo e($data->question); ?></option>
        <?php $__empty_1 = true; $__currentLoopData = $options->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($option->id); ?>" <?php echo e($id==$option->id?'selected':''); ?>><?php echo e($option->value); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php endif; ?>
    </select>
<?php endif; ?><?php /**PATH /var/www/test-projects/survey/resources/views/surveys/fields/dropdown.blade.php ENDPATH**/ ?>