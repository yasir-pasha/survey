<?php if(isset($view)): ?>
    <p class="text-info">
        <?php echo e(isset($answers[$question->id])?$answers[$question->id]->answer:'N/A'); ?>

    </p>
<?php else: ?>
    <textarea class="form-control" type="text" name="question_id[<?php echo e($data->id); ?>]"><?php echo e(isset($answers[$question->id])?$answers[$question->id]->answer:''); ?></textarea>
<?php endif; ?><?php /**PATH /var/www/test-projects/survey/resources/views/surveys/fields/textarea.blade.php ENDPATH**/ ?>