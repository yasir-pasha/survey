<?php $__env->startSection('content'); ?>

    <div class="col-md-12">
        <div class="card">
            <div class="card-header"><?php echo e(__('Surveys')); ?></div>

            <div class="card-body">
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Survey Name</th>
                        <th scope="col">Survey Description</th>
                        <th scope="col">Creation Date</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $surveys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $survey): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <th scope="row"><?php echo e($survey->id); ?></th>
                            <td><?php echo e($survey->name); ?></td>
                            <td><?php echo e($survey->description); ?></td>
                            <td><?php echo e(\Carbon\Carbon::parse($survey->created_at)->format('d-m-Y')); ?></td>
                            <td><?php echo e(config('constants.SURVEY_STATUS.'.$survey->status)); ?></td>
                            <td>
                                <?php if($survey->status !== 2): ?>
                                    <a href="<?php echo e(route('surveys.fill',$survey->id)); ?>" class="btn-link">Fill</a>
                                <?php endif; ?>
                                <?php if($survey->status === 2): ?>
                                    <a href="<?php echo e(route('surveys.view',$survey->id)); ?>" class="btn-link">View</a>

                                <?php endif; ?>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center">No Survey found</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/test-projects/survey/resources/views/surveys/index.blade.php ENDPATH**/ ?>