<?php
  return [
    'SURVEY_STATUS' => [
      0 => 'Pending',
      1 => 'Partially Filled',
      2 => 'Completed'
    ]
  ];